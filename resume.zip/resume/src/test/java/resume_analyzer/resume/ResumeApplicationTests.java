package resume_analyzer.resume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeApplicationTests {

	@Test
	void contextLoads() {
	}

}
